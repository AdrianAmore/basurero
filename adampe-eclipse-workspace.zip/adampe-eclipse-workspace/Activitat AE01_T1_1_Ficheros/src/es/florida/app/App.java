package es.florida.app;

import java.io.File;
import java.text.CharacterIterator;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Scanner;

public class App {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("1. getInformacio");
		System.out.println("2. creaCarpeta");
		System.out.println("3. creaFitxer");
		System.out.println("4. elimina");
		System.out.println("5. renomena");
		System.out.print("Introdueix la funci� que vols executar: ");
		int metodo = scan.nextInt();
		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		switch (metodo) {

		case 1:
			getInformacio(f);
			break;
		case 2:
			creaCarpeta(f);
			break;

		}

	}

	public static void getInformacio(File f) {
		System.out.println("El directori es: " + f.getName());
		if (f.isDirectory()) {
			System.out.println("Es un directori");
			System.out.println("N� d'elements: " + f.listFiles().length);
			System.out.println("Espai lliure: " + humanReadableByteCountSI(f.getFreeSpace()));
			System.out.println("Espai disponible: " + humanReadableByteCountSI(f.getUsableSpace()));
			System.out.println("Espai total: " + humanReadableByteCountSI(f.getTotalSpace()));

		} else {
			System.out.println("Es un fitxer");
			System.out.println("La seua grandaria es: " + f.length() + " bytes");
		}
		System.out.println("La ubicaci� es: " + f.getPath());
		SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
		String fecha = myFormat.format(f.lastModified());
		System.out.println("Ultima data de modificaci�: " + fecha);
		if (f.isHidden()) {
			System.out.println("Es ocult");
		} else {
			System.out.println("No es ocult");
		}
	}

	public static void creaCarpeta(File f) {
		if(f.mkdir()) {
			System.out.println("Carpeta creada amb exit!");
		}
	}

	// Funciones que no tienen que ver con la actividad

	public static String humanReadableByteCountSI(long bytes) { // Funci�n que convierte bytes a MB/GB etc... (De
																// internet)
		if (-1000 < bytes && bytes < 1000) {
			return bytes + " B";
		}
		CharacterIterator ci = new StringCharacterIterator("kMGTPE");
		while (bytes <= -999_950 || bytes >= 999_950) {
			bytes /= 1000;
			ci.next();
		}
		return String.format("%.1f %cB", bytes / 1000.0, ci.current());
	}

}
