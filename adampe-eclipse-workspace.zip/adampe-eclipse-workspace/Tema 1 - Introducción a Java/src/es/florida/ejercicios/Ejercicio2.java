package es.florida.ejercicios;
import java.util.Scanner;
public class Ejercicio2 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.print("Introduce tu nombre: ");
        String nombre = scan.nextLine();
        System.out.println("Hola: " + nombre);
    }

}
