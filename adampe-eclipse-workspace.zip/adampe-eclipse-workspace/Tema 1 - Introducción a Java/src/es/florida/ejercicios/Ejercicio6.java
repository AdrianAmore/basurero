package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		int suma = 0;
		for (int i = 1; i < 6; i++) {
			System.out.print("Introduce el valor " + i +": ");
			int valor = scan.nextInt();
			suma += valor;
		}
		System.out.println("La suma es: " + suma);
	}

}
