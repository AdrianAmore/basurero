package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		System.out.print("Introduce el primer valor: ");
		int valor1 = scan.nextInt();
		System.out.print("Introduce el segundo valor: ");
		int valor2 = scan.nextInt();
		if (valor1 > valor2) {
			System.out.print(valor1 + " es el numero mayor y " + valor2 + " el menor");
		}else if(valor1<valor2) {
			System.out.print(valor1 + " es el numero menor y " + valor2 + " el mayor");
		}else {
			System.out.print("Los numeros son iguales");
		}
	}

}
