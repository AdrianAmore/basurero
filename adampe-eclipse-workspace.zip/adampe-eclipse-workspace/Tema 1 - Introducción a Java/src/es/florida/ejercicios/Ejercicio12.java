package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio12 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] notas = new int[10];
		for (int i = 0; i < 10; i++) {
			System.out.print("Introduce una nota del 0 al 10: ");
			int num = scan.nextInt();
			if (num >= 0 && num <= 10) {
				notas[i] = num;
			} else {
				System.out.println("Introduce un numero v�lido: ");
				i--;
			}

		}
	}

}
