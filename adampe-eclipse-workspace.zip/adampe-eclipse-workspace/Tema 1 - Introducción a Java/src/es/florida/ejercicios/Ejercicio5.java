package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		int valor1;
		int valor2;
		do {
			System.out.print("Introduce el primer valor: ");
			valor1 = scan.nextInt();
			System.out.print("Introduce el segun3do valor: ");
			valor2 = scan.nextInt();
		} while (valor1 != valor2);
	}
}
