package es.florida.ejercicios;

public class Ejercicio1 {

    public static void main(String[] args) throws Exception {
        int a = 3;
        int b = 6;
        System.out.println((a + b));
    }
}
