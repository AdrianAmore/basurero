package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		int suma = 0;
		int contador = 0;
		while (contador != 5) {
			System.out.print("Introduce el valor " + (contador + 1) + ": ");
			int valor = scan.nextInt();
			suma += valor;
			contador++;
		}
		System.out.println("La suma es: " + suma);
	}

}
