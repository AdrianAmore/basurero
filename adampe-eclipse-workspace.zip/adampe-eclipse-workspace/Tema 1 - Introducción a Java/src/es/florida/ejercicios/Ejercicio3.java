package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		System.out.print("Introduce el primer valor: ");
		int valor1 = scan.nextInt();
		System.out.print("Introduce el segundo valor: ");
		int valor2 = scan.nextInt();
		System.out.println("La suma de los valores es: " + (valor1 + valor2));
	}

}
