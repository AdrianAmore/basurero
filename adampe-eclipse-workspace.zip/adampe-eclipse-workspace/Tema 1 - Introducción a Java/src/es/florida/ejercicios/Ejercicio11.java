package es.florida.ejercicios;

import java.util.Scanner;

public class Ejercicio11 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Introduce tu DNI sin letra: ");
		int dni = scan.nextInt();
		String juegoCaracteres = "TRWAGMYFPDXBNJZSQVHLCKE";

		int modulo = dni % 23;

		char letra = juegoCaracteres.charAt(modulo);

		System.out.print("Tu DNI es: " + dni + letra);

	}

}
