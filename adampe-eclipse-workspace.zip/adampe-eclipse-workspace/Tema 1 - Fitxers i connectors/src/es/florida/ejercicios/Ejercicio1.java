package es.florida.ejercicios;

import java.io.File;

public class Ejercicio1 {

	public static void main(String[] args) {

		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		System.out.println("El directorio es: " + f);
	}

}
