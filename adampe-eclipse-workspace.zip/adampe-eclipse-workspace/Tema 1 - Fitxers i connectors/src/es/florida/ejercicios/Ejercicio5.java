package es.florida.ejercicios;

import java.io.File;

public class Ejercicio5 {

	public static void main(String[] args) {

		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		String[] filtro = f.list(new FiltroExtension(args[1])); //Filtro
		System.out.println("El directorio es: " + f);
		if (f.exists()) { // Comprueba si el directorio existe
			File ficheros[] = f.listFiles(); // Lista los ficheros por extension
			System.out.println("Su contenido por extension es: ");
			for (int i = 0; i < filtro.length; i++) {
				System.out.println(filtro[i]);
			}
		} else {
			System.out.println("El directorio proporcionado no existe.");
		}

	}

}
