package es.florida.ejercicios;

import java.io.File;

public class Ejercicio4 {

	public static void main(String[] args) {
		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		if (f.exists()) { // Comprueba si el directorio existe
			System.out.println("El directorio existe");

		} else {
			System.out.println("El directorio no existe.");
		}

	}

}
