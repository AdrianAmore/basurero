package es.florida.ejercicios;

import java.io.File;
import java.util.ArrayList;

public class Ejercicio7 {

	public static void main(String[] args) {

		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		System.out.println("El directorio es: " + f);
		if (f.exists()) { // Comprueba si el directorio existe

			if (args.length > 1) { // Si tiene extensiones
				ArrayList<String> extensiones = new ArrayList<String>();
				for (int i = 1; i < args.length; i++) {
					extensiones.add(args[i]); // A�adimos las extensiones a una lista
				}

				int contador = 0;
				System.out.println("Su contenido por extension es: ");
				while (extensiones.size() > contador) {

					String[] filtro = f.list(new FiltroExtension(extensiones.get(contador))); // Filtro
					for (int h = 0; h < filtro.length; h++) {
						System.out.println(filtro[h]);
					}

					contador++;

				}

			} else {
				File ficheros[] = f.listFiles(); // Lista los ficheros SIN EXTENSION
				System.out.println("Su contenido es: ");
				for (int i = 0; i < ficheros.length; i++) {
					System.out.println(ficheros[i].getName());
				}
			}
		} else {
			System.out.println("El directorio proporcionado no existe.");

		}
	}
}
