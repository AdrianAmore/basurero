package es.florida.ejercicios;

import java.io.File;

public class Ejercicio3 {

	public static void main(String[] args) {
		String sDirectorio = args[0];
		File f = new File(sDirectorio);
		System.out.println("El directorio es: " + f);
		if (f.exists()) { //Comprueba si el directorio existe
			File ficheros[] = f.listFiles(); // Lista los ficheros
			System.out.println("Su contenido es: ");
			for (int i = 0; i < ficheros.length; i++) {
				System.out.println(ficheros[i].getName());
			}
		} else {
			System.out.println("El directorio proporcionado no existe.");
		}

	}

}
