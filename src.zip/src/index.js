import React from 'react';
import ReactDOM from 'react-dom';
import  Principal  from './components/principal.js';
import './index.css';

ReactDOM.render(<Principal></Principal>, document.getElementById('root'));