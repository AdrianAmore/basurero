import React from 'react';
import Imagen from './images/a.jpg';

export default function Cabecera(){
    return(<div className="cabecera">
        <h1 className="tituloCabecera">Titulo</h1>
    </div>
        )
}
