import React from 'react';
import Imagen from './images/a.jpg';

export default function Cabecera(){
    return(<div className="head">
        <h1>Titulo</h1>
    </div>
        )
}
