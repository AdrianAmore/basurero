import React from 'react'

export default function Footer() {
    return (
        <p className="footer">Adrián Amore Peris Contacto: adampe@floridauniversitaria.es</p>
    )
}
