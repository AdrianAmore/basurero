import React from 'react'
import Menu from './menu.js';
import Titulo from './titulo.js';
import Contenido from './contenido.js';

const miComponente = () => {
    const menu = React.createElement('menu', null, React.createElement(Menu, null));
    const titulo = React.createElement('titulo', null, React.createElement(Titulo, null));
    const contenido = React.createElement(Contenido, null);
    const miDiv = React.createElement('div', null, menu, titulo, contenido);
    return miDiv;
}
export default function Seccion() {
    return (
        miComponente()
    )
}
