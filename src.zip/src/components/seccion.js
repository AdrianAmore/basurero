import React from 'react'
import Menu from './menu.js';
import Titulo from './titulo.js';
import Contenido from './contenido.js';

export default function Seccion() {
    return (
        <div className="seccion">
            <Menu></Menu>
            <Titulo></Titulo>
            <Contenido></Contenido>
        </div>
    )
}
