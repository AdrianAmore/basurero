import React from 'react';
import Cabecera from './cabecera.js';
import Seccion from './seccion.js';
import Footer from './footer.js';
import reactDom from 'react-dom';
const miComponente = () => {
    const cabe = React.createElement('cabecera', null, React.createElement(Cabecera, null));
    const secc = React.createElement('seccion', null, React.createElement(Seccion, null));
    const foot = React.createElement(Footer, null);
    const miDiv = React.createElement('div', null, cabe, secc, foot);
    return miDiv;
}


export default function Principal() {
    return (
        miComponente()
    )
}
