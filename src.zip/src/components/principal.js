import React from 'react';
import Cabecera from './cabecera.js';
import Seccion from './seccion.js';
import Footer from './footer.js';
import reactDom from 'react-dom';

export default function Principal() {
    return (
        <div className="principal">
            <Cabecera></Cabecera>
            <Seccion></Seccion>
            <Footer></Footer>
        </div>
    )
}
