import React, { Component } from 'react'
import ReactPlayer from 'react-player'

export default function Contenido() {
    return (
        <div className="contenido">
            <p className="parrafo">Texto</p>
            <div className="video"><ReactPlayer
          url='https://www.youtube.com/watch?v=EMk6nom1aS4'
          className='react-player'
          playing
        /></div>
            
        </div>
    )
}
