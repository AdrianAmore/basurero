import React, { Component } from 'react'
import ReactPlayer from 'react-player'

export default function Contenido() {
    return (
        <div>
            <p>Texto</p>
            <ReactPlayer
          url='https://www.youtube.com/watch?v=EMk6nom1aS4'
          className='react-player'
          playing
          width='100%'
          height='100%'
        />
        </div>
    )
}
