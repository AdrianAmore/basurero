import React from 'react'

export default function Titulo() {
    return (
        <h1>Titulo de nivel 1</h1>
    )
}
