import React from 'react'

export default function Titulo() {
    return (
        <h1 className="titulo">Titulo de nivel 1</h1>
    )
}
