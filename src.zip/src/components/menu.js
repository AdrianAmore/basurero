import React from 'react'
import Imagen from './images/a.jpg';

export default function Menu() {
    return (
        <div>
            <img src={Imagen} alt="Imagen" />
            <ul>
                <li><a href="https://www.youtube.com/watch?v=EMk6nom1aS4"></a>1</li>
                <li><a href="https://www.youtube.com/watch?v=EMk6nom1aS4"></a>2</li>
                <li><a href="https://www.youtube.com/watch?v=EMk6nom1aS4"></a>3</li>
            </ul>
        </div>

    )
}
