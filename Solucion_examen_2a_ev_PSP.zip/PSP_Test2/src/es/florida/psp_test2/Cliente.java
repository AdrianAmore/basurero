package es.florida.psp_test2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) {
		
		try {
			
			System.out.println("CLIENTE: Arranca cliente");
			System.out.println("CLIENTE: Conexion al servidor");
			InetSocketAddress direccion = new InetSocketAddress("localhost", 9876);
			Socket socket = new Socket();
			socket.connect(direccion);
			
			//Preparar buffer para lectura
			InputStream is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader bfr = new BufferedReader(isr);
			
			//Preparar printwriter para escritura
			OutputStream os = socket.getOutputStream();
			PrintWriter pw = new PrintWriter(os);
			
			Scanner teclado = new Scanner(System.in);
			System.out.print("CLIENTE: Usuario: ");
			String usuario = teclado.nextLine();
			
			pw.print(usuario + "\n"); pw.flush();
			System.out.println("CLIENTE: Envio de usuario al servidor");
			
			String respuestaUsuario = bfr.readLine();
			
			System.out.println("CLIENTE: Recibida resupuesta del servidor (usuario): " + respuestaUsuario);
			
			if (!respuestaUsuario.equals("200 OK")) {
				socket.close();
				System.out.println("CLIENTE: ERROR: cierra la conexion");
				return;
			} 

			System.out.print("CLIENTE: Contrasenya: ");
			String contrasenya = teclado.nextLine();
			
			pw.print(contrasenya + "\n"); pw.flush();
			
			System.out.println("CLIENTE: Envio de contrasenya al servidor");
			
			String respuestaContrasenya = bfr.readLine();
			
			System.out.println("CLIENTE: Recibida resupuesta del servidor (contrasenya): " + respuestaContrasenya);
			
			if (!respuestaContrasenya.equals("200 OK")) {
				socket.close();
				System.out.println("CLIENTE: ERROR: cierra la conexion");
				return;
			}
			
			pw.print("PREPARADO\n"); pw.flush();
			
			System.out.println("CLIENTE: Envio palabra clave PREPARADO al servidor");
			
			String numeroLineas = bfr.readLine();
			
			System.out.println("CLIENTE: Preparado para recibir " + numeroLineas + " lineas del servidor");
			
			for (int i = 0; i < Integer.parseInt(numeroLineas); i++) {
				String linea = bfr.readLine();
				System.out.println("CLIENTE: Linea " + (i + 1) + ": " + linea);
			}
			
			System.out.println("CLIENTE: FIN");
			
			teclado.close();
			bfr.close();
			pw.close();
			socket.close();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
