package es.florida.psp_test2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class Peticion implements Runnable {
	
	Socket socket;

	public Peticion(Socket socket){
		this.socket = socket;
	}

	@Override
	public void run() {
		
		try {
			//Preparar buffer para lectura
			InputStream is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader bfr = new BufferedReader(isr);
			
			//Preparar printwriter para escritura
			OutputStream os = socket.getOutputStream();
			PrintWriter pw = new PrintWriter(os);
			
			System.err.println("SERVIDOR: Esperando nombre de usuario...");
			
			String usuario = bfr.readLine();
			
			System.err.println("SERVIDOR: Recibido nombre de usuario '" + usuario + "' -> Comprobar lista");
			
			File ficheroUsuarios = new File("Usuarios_autorizados.txt");
			FileReader fr = new FileReader(ficheroUsuarios);
			BufferedReader brFichero = new BufferedReader(fr);
			String linea = brFichero.readLine();
			int idUsuario = 0;
			String respuestaUsuario = "ERROR";
			while(linea != null) {
				if (linea.equals(usuario)) {
					respuestaUsuario = "200 OK";
					break;
				}
				linea = brFichero.readLine();
				idUsuario++;
			}
			brFichero.close();
			fr.close();
			
			pw.write(respuestaUsuario + "\n"); pw.flush();
			
			System.err.println("SERVIDOR: Enviada respuesta a cliente (usuario): " + respuestaUsuario);
			
			String contrasenya = bfr.readLine();
			
			System.err.println("SERVIDOR: Recibida contrasenya de usuario " + contrasenya + " -> Comprobar lista");
			
			File ficheroContrasenyas = new File("Contrasenyas_autorizadas.txt");
			fr = new FileReader(ficheroContrasenyas);
			brFichero = new BufferedReader(fr);
			String respuestaContrasenya = "ERROR";
			for (int i = 0; i <= idUsuario; i++) {
				linea = brFichero.readLine();
			}
			if (linea.equals(contrasenya)) {
				respuestaContrasenya = "200 OK";
			}
			brFichero.close();
			fr.close();
			
			pw.write(respuestaContrasenya + "\n"); pw.flush();
			
			System.err.println("SERVIDOR: Enviada respuesta a cliente (contrasenya): " + respuestaContrasenya);
			
			String preparado = bfr.readLine();
			if (!preparado.equals("PREPARADO")) {
				socket.close();
				System.err.println("SERVIDOR: ERROR: cierra la conexion");
				return;
			}
			
			int lineasFichero = 0;
			ArrayList<String> listaLineas = new ArrayList<String>();
			File ficheroContenido = new File("Contenido_a_enviar.txt");
			fr = new FileReader(ficheroContenido);
			brFichero = new BufferedReader(fr);
			while((linea = brFichero.readLine()) != null) {
				lineasFichero++;
				listaLineas.add(linea);
			}
			brFichero.close();
			fr.close();
			
			pw.write(String.valueOf(lineasFichero) + "\n"); pw.flush();
			
			System.err.println("SERVIDOR: Indicar numero de lineas a cliente: " + lineasFichero);
			
			for (int i = 0; i < lineasFichero; i++) {
				pw.write(listaLineas.get(i) + "\n"); pw.flush();
			}
			
			System.err.println("SERVIDOR: Enviadas " + lineasFichero + " lineas a cliente");
			
			System.err.println("SERVIDOR: FIN");
			
			bfr.close();
			pw.close();
			socket.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	
}
