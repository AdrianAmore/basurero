package es.florida.AE2_PSP;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Lanzador {

	public static String leer(String path) {
		String data = "";
		try {
			File myObj = new File(path);
			Scanner myReader = new Scanner(myObj);

			while (myReader.hasNextLine()) {
				data = myReader.nextLine(); // Lee la linea y le a�ade una coma para poder separarla mas tarde.
				String[] valores = data.split(",");
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return valores;
	}

	// Recibe un file con la ruta donde se va a crear la carpeta y la crea.
	// Aun que no era necesario he decidido agrupar los archivos de texto dentro de
	// una carpeta para mayor organizaci�n.
	public static void creaCarpeta(File f) {

		String dir = f + "//Probabilitats_NEOs"; // Y le asigna el nombre para crearla.
		File f1 = new File(dir);
		f1.mkdirs();
	}

	public void lanzar(String nombreNEO, double posicionNEO, double velocidadNEO) {
		String clase = "es.florida.AE2_PSP.Pruebas";
		try {

			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(nombreNEO);
			command.add(Double.toString(posicionNEO));
			command.add(Double.toString(velocidadNEO));

// System.out.println("Comando que se pasa a ProcessBuilder: " + command);
// System.out.println("Comando a ejecutar en cmd.exe: " + command.toString().replace(",",""));

			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.inheritIO().start();
// Process process = builder.start();
			//process.waitFor();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		Lanzador l = new Lanzador();
		File p = new File(System.getProperty("user.dir")); // Obtenemos el directorio actual.
		creaCarpeta(p);
		int cores = Runtime.getRuntime().availableProcessors();
		Scanner sc;
		sc = new Scanner(p);
		int i = 0;
		while(sc.hasNextLine() && cores > i) {
			String linea = sc.nextLine();
			
			
			}
		
		
		
		
	}

}
